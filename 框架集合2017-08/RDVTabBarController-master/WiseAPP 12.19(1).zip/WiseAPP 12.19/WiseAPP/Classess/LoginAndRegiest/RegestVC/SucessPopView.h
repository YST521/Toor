//
//  SucessPopView.h
//  WiseAPP
//
//  Created by app on 16/10/17.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SucessPopView : UIView

@property(nonatomic,strong)UIButton*backBtn;
@property(nonatomic,strong)UIButton*doneBtn;

@end
