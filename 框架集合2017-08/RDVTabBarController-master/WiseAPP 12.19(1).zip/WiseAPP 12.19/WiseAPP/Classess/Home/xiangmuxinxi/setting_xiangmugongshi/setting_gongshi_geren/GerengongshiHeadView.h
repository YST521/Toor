//
//  GerengongshiHeadView.h
//  WiseAPP
//
//  Created by app on 16/12/7.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GerengongshiHeadView : UIView

@property(nonatomic,strong)UILabel* titleLa;
@property(nonatomic,strong)UILabel* numberLa;


@end
