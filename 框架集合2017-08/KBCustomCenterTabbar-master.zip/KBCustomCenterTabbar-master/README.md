# KBCustomCenterTabbar
利用系统的tabbar定义类似于掌上生活的中间按钮凸起的tabbar, 实现起来简单, 代码简便, 整个圆形都是点击区域, 希望能帮到你, 如有问题, 可发邮件一起交流

![demo示例](http://i2.buimg.com/dce543b365e4e668.gif)
