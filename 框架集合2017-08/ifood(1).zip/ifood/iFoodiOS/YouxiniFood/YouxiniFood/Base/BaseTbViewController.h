//
//  BaseTbViewController.h
//  Hjxq
//
//  Created by 吴瑞洲 on 16/1/29.
//  Copyright © 2016年 Ray. All rights reserved.
//

#import "HYBaseViewController.h"

@interface BaseTbViewController : HYBaseViewController

@property (nonatomic, retain) UITableView *tb;
@property (nonatomic, assign) int pageIndex;
@property (nonatomic, assign) BOOL isMore;
@property (nonatomic, retain) UIButton *moreButton;
@property (nonatomic, retain) UIActivityIndicatorView *activityView;
@property (nonatomic, assign) BOOL isLoading;

- (void)loadMoreAction;
- (void)endLoadMore;

@property (nonatomic, retain) NSMutableArray *dataSource;

@end
