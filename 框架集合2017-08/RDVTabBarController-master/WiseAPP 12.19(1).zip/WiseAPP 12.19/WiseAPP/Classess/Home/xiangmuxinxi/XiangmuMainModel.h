//
//  XiangmuMainModel.h
//  WiseAPP
//
//  Created by app on 16/11/17.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XiangmuMainModel : NSObject
@property(nonatomic,assign)int xuangmuxinxiID;
@property(nonatomic,strong)NSString* projectname;
@end
