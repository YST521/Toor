//
//  KaoqinHomeCollectionViewCell.h
//  WiseAPP
//
//  Created by yst911521 on 2016/11/29.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KaoqinHomeCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)UIImageView*bgimageView;
@property(nonatomic,strong)UIImageView*iconImageView;
@property(nonatomic,strong)UILabel* titleLabel;
@property(nonatomic,strong)UIView*upView;
@end
