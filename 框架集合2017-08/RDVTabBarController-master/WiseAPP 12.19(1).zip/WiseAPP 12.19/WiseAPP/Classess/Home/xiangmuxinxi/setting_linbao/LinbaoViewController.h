//
//  LinbaoViewController.h
//  WiseAPP
//
//  Created by app on 16/10/31.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@interface LinbaoViewController : BaseViewController

@end
