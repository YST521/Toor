//
//  PaddPeopleTableViewCell.h
//  WiseAPP
//
//  Created by app on 16/11/2.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaddPeopleTableViewCell : UITableViewCell
@property(nonatomic,strong)UIButton* leftBtn;
@property(nonatomic,strong)UILabel* leftLa;
@property(nonatomic,strong)UILabel* rightLa;
@property(nonatomic,strong)UILabel* rightNumLa;
@end
