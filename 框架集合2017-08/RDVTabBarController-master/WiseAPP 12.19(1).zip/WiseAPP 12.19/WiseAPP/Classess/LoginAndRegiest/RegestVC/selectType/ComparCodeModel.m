//
//  ComparCodeModel.m
//  WiseAPP
//
//  Created by app on 16/11/10.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "ComparCodeModel.h"

@implementation ComparCodeModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{

}
@end
