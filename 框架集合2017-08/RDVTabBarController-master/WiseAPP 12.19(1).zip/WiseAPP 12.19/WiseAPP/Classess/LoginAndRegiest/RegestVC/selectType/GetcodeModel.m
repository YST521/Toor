//
//  GetcodeModel.m
//  WiseAPP
//
//  Created by app on 16/10/20.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "GetcodeModel.h"

@implementation GetcodeModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{


}

@end
