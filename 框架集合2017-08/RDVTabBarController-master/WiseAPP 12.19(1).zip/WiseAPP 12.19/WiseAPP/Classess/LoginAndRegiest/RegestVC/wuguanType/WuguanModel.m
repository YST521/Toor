//
//  WuguanModel.m
//  WiseAPP
//
//  Created by app on 16/10/25.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "WuguanModel.h"

@implementation WuguanModel

@end
