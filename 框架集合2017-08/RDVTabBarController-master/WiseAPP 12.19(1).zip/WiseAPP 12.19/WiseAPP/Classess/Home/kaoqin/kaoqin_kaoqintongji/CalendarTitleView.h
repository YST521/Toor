//
//  CalendarTitleView.h
//  SoHeroAttendanceAPP
//
//  Created by 冯佳玉 on 16/9/27.
//  Copyright © 2016年 冯佳玉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CalendarTitleView : UIView
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UIButton *dateChooseButton;
@property (weak, nonatomic) IBOutlet UIButton *todayButton;

@end
