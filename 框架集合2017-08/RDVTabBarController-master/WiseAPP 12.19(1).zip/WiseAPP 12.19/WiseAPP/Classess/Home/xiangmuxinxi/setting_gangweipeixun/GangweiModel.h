//
//  GangweiModel.h
//  WiseAPP
//
//  Created by app on 16/11/24.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GangweiModel : NSObject
//@property(nonatomic,assign)int gangweiID;
@property(nonatomic,assign)int gangweipeixunID;
@property(nonatomic,strong)NSArray* image;
@property(nonatomic,copy)NSString* trainingcontent;
@property(nonatomic,copy)NSString*  trainingname;
@end
