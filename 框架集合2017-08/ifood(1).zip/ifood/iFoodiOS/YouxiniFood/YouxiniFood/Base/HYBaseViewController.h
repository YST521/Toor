//
//  HYBaseViewController.h
//  17zwd
//
//  Created by D_han on 13-11-2.
//  Copyright (c) 2013年 Hanyun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface HYBaseViewController : UIViewController

@property (nonatomic, retain) UISwipeGestureRecognizer *swipGesture;

- (AppDelegate*)appDelegate;

- (int)deviceVersion;

- (void)backAction:(id)button;

@property (nonatomic, retain) UIBarButtonItem *backItem;


- (void)showLoadView;
- (void)closeLoadView;


-(void)showTipInfo:(NSString*)tipInfo;

@end
