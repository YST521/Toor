//
//  CustomTextFile.m
//  WiseAPP
//
//  Created by yst911521 on 2016/10/30.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "CustomTextFile.h"

@implementation CustomTextFile

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
