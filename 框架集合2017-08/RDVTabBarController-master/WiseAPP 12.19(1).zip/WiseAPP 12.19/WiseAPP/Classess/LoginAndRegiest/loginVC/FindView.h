//
//  FindView.h
//  WiseAPP
//
//  Created by app on 16/10/16.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FindView : UIView

@property(nonatomic,strong)UITextField*find_phoneNum;
@property(nonatomic,strong)UITextField*validitionCode;
@property(nonatomic,strong)UITextField*firstPassword;
@property(nonatomic,strong)UITextField*secendPassword;
@property(nonatomic,strong)UIButton*getCodeBtn;
@property(nonatomic,strong)UIButton*commitButton;
@property(nonatomic,strong)UIButton*firstBtneye;
@property(nonatomic,strong)UIButton*secendBtneye;

@end
