//
//  ComparCodeModel.h
//  WiseAPP
//
//  Created by app on 16/11/10.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ComparCodeModel : NSObject
@property(nonatomic,assign)int resultCode;
@property(nonatomic,strong)NSString*  resultMessage;
@end
