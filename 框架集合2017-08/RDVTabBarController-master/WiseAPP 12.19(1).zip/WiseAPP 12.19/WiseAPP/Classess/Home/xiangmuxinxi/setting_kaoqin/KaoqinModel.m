//
//  KaoqinModel.m
//  WiseAPP
//
//  Created by app on 16/11/28.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "KaoqinModel.h"

@implementation KaoqinModel

@end
