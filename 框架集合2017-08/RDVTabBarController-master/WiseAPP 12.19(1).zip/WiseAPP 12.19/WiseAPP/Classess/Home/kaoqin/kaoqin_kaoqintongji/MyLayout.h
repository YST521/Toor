//
//  MyLayout.h
//  SoHeroAttendanceAPP
//
//  Created by 冯佳玉 on 16/9/26.
//  Copyright © 2016年 冯佳玉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyLayout : UICollectionViewFlowLayout

@end
