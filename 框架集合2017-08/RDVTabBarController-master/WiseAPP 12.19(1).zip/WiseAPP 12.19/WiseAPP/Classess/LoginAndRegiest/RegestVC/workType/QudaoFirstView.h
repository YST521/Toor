//
//  QudaoFirstView.h
//  WiseAPP
//
//  Created by app on 16/10/24.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QudaoFirstView : UIView
@property(nonatomic,strong)UIButton* listBtn;
@property(nonatomic,strong)UIButton* qudaoBackBtn;
@property(nonatomic,strong)UIButton* qudaoDoneBtn;
@property(nonatomic,assign)NSInteger indexBtn;
@property(nonatomic,strong)UIButton* firstBtn;
@property(nonatomic,strong)UIButton* secendBtn;
@property(nonatomic,strong)UIButton* thirdBtn;

@end
