//
//  IdCartdBmodel.h
//  WiseAPP
//
//  Created by app on 16/10/26.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IdCartdBmodel : NSObject

@property(nonatomic,copy)NSString* croppedImage;
@property(nonatomic,copy)NSString* validdate;
@property(nonatomic,copy)NSString* authority;
@property(nonatomic,copy)NSString* code;


@end
