//
//  GRGSViewController.h
//  WiseAPP
//
//  Created by app on 16/11/29.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@interface GRGSViewController : BaseViewController

@end
