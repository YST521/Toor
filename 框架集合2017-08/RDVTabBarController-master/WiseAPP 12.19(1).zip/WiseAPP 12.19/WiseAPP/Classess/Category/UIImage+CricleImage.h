//
//  UIImage+CricleImage.h
//  百思不得其姐
//
//  Created by lanou3g on 16/6/2.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (CricleImage)
-(UIImage*)circleImage;

@end
