//
//  MainTabBarController.m
//  YouxiniFood
//
//  Created by youxin on 2017/7/26.
//  Copyright © 2017年 YST. All rights reserved.
//

#import "MainTabBarController.h"
#import "MainNavigationController.h"
#import "OrderViewController.h"
#import "WiseLifeViewController.h"
#import "MYViewController.h"
#import "TabBar.h"

@interface MainTabBarController ()
@property(nonatomic,strong)NSArray *titlesArray;
@end

@implementation MainTabBarController


+ (void)initialize
{
    // 通过appearance统一设置所有UITabBarItem的文字属性
    // 后面带有UI_APPEARANCE_SELECTOR的方法, 都可以通过appearance对象来统一设置
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = [UIFont systemFontOfSize:12];
    attrs[NSForegroundColorAttributeName] = [UIColor orangeColor];
    
    NSMutableDictionary *selectedAttrs = [NSMutableDictionary dictionary];
    selectedAttrs[NSFontAttributeName] = attrs[NSFontAttributeName];
    selectedAttrs[NSForegroundColorAttributeName] = [UIColor orangeColor];
    
    UITabBarItem *item = [UITabBarItem appearance];
    [item setTitleTextAttributes:attrs forState:UIControlStateNormal];
    [item setTitleTextAttributes:selectedAttrs forState:UIControlStateSelected];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    [self creatVC]; //系统
    
    // 添加子控制器
    [self setupChildVc:[[OrderViewController alloc] init] title:@"订餐.吃饭" image:@"account_highlight" selectedImage:@"account_normal"];
    
    [self setupChildVc:[[WiseLifeViewController alloc] init] title:@"智慧生活" image:@"home_highlight" selectedImage:@"home_normal"];
    
    [self setupChildVc:[[MYViewController alloc] init] title:@"我的" image:@"mycity_highlight" selectedImage:@"mycity_normal"];
    

    
    // 更换tabBar
   [self setValue:[[TabBar alloc] init] forKeyPath:@"tabBar"];
}

/**
 * 初始化子控制器
 */
- (void)setupChildVc:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    // 设置文字和图片
    vc.navigationItem.title = title;
    vc.tabBarItem.title = title;
    vc.tabBarItem.image = [UIImage imageNamed:image];
    vc.tabBarItem.selectedImage = [UIImage imageNamed:selectedImage];
    
    // 包装一个导航控制器, 添加导航控制器为tabbarcontroller的子控制器
    MainNavigationController *nav = [[MainNavigationController alloc] initWithRootViewController:vc];
    [self addChildViewController:nav];
}

//-(void)creatVC{
//    
//    OrderViewController *orderVC    = [[OrderViewController alloc]init];
//    WiseLifeViewController *wiseVC  = [[WiseLifeViewController alloc]init];
//    MYViewController*myVC           = [[MYViewController alloc]init];
//
//    orderVC.title = @"订餐.吃饭";
//    wiseVC.title = @"智慧生活";
//    myVC.title = @"我的";
//    
//    
//    MainNavigationController*orderNA =[[MainNavigationController alloc]initWithRootViewController:orderVC];
//    MainNavigationController*wiseNA =[[MainNavigationController alloc]initWithRootViewController:wiseVC];
//    MainNavigationController*myNA =[[MainNavigationController alloc]initWithRootViewController:myVC];
//    
//    self.selectedIndex = 0;
//    
//    
//    self.viewControllers = @[orderNA,wiseNA,myNA];
//    
//}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
