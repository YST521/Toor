//
//  POPView.h
//  WiseAPP
//
//  Created by app on 16/10/26.
//  Copyright © 2016年 YST. All rights reserved.
//

//公用弹框
#import <UIKit/UIKit.h>

@interface POPView : UIView
@property(nonatomic,strong)UILabel* popTitle;
@property(nonatomic,strong)UITextField* popTextFile;
@property(nonatomic,strong)UIButton* popDoneBtn;

@end
