//
//  BanciAddView.h
//  WiseAPP
//
//  Created by app on 16/11/21.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BanciAddView : UIView
@property(nonatomic,strong)UITextField* banciName;
@property(nonatomic,strong)UITextField*  starTime;
@property(nonatomic,strong)UITextField*  endTime;
@property(nonatomic,strong)UIImageView* bgImage;
@end
