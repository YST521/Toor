//
//  PublieTableViewCell.h
//  WiseAPP
//
//  Created by app on 16/10/31.
//  Copyright © 2016年 YST. All rights reserved.
//


//去填写模式cell布局

#import <UIKit/UIKit.h>

@interface PublieTableViewCell : UITableViewCell
//cell
@property(nonatomic,strong)UILabel* leftLa;
@property(nonatomic,strong)UILabel* rightLa;
@property(nonatomic,strong)UIButton* rightBtn;
@end
