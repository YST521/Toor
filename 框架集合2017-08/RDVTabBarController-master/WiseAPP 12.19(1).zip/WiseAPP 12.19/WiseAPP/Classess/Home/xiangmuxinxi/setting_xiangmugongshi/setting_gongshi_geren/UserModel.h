//
//  UserModel.h
//  WiseAPP
//
//  Created by app on 16/12/7.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserModel : NSObject
@property(nonatomic,assign)int userID;
@property(nonatomic,copy)NSString* name;
@property(nonatomic,copy)NSString*  username;

@end
