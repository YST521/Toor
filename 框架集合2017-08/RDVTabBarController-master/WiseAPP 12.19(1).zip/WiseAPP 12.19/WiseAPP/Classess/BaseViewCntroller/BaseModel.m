//
//  BaseModel.m
//  WiseAPP
//
//  Created by app on 16/11/24.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{



}

@end
