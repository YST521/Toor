//
//  BanhuiShowViewController.h
//  WiseAPP
//
//  Created by app on 16/11/23.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@class  BanhuiModel;

@interface BanhuiShowViewController : BaseViewController
@property(nonatomic,strong)BanhuiModel* model;
@end
