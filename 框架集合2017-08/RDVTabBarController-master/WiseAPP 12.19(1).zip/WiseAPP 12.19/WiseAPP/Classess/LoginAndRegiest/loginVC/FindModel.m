//
//  FindModel.m
//  WiseAPP
//
//  Created by yst911521 on 2016/11/27.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "FindModel.h"

@implementation FindModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{


}
@end
