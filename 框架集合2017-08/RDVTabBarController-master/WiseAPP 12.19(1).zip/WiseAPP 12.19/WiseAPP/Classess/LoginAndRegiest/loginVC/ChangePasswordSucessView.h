//
//  ChangePasswordSucessView.h
//  WiseAPP
//
//  Created by app on 16/10/16.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangePasswordSucessView : UIView
@property(nonatomic,strong)UIButton*loginButton;
@end
