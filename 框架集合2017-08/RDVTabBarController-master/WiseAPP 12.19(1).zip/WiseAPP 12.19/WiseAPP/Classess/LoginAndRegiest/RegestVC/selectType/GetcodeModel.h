//
//  GetcodeModel.h
//  WiseAPP
//
//  Created by app on 16/10/20.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GetcodeModel : NSObject
@property(nonatomic,assign)int reultCode;
@property(nonatomic,strong)NSString* reultMessage;
@property(nonatomic,strong)NSString* data;

@end
