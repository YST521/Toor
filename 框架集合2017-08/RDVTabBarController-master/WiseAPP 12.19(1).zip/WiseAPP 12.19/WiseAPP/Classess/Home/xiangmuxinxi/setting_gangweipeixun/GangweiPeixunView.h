//
//  GangweiPeixunView.h
//  WiseAPP
//
//  Created by app on 16/11/1.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GangweiPeixunView : UIView
@property(nonatomic,strong)UITextField* produceFile;
@property(nonatomic,strong)UITextView * contentFile;
@property(nonatomic,strong)UIButton* addImageBtn;
@property(nonatomic,strong)UIView* addImageView;
@end
