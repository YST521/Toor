//
//  RightTableViewCell.h
//  WiseAPP
//
//  Created by app on 16/11/30.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RightTableViewCell : UITableViewCell
@property(nonatomic,strong)UIImageView* leftPeopleImage;
@property(nonatomic,strong)UILabel* peopleLa;
@property(nonatomic,strong)UIButton* deleateBtn;
@end
