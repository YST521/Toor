//
//  AnnotionModel.m
//  WiseAPP
//
//  Created by app on 16/11/3.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "AnnotionModel.h"

@implementation AnnotionModel

@end
