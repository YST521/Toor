//
//  XujianquanshuFirstTableViewCell.h
//  WiseAPP
//
//  Created by yst911521 on 2016/11/27.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XujianquanshuFirstTableViewCell : UITableViewCell

@property(nonatomic,strong)UILabel* leftNumLa;
@property(nonatomic,strong)UILabel* leftAdressLa;
@property(nonatomic,strong)UILabel* rightLa;
@property(nonatomic,strong)UIImageView*rightImage;
@end
