//
//  GangweiSetShowViewController.h
//  WiseAPP
//
//  Created by app on 16/11/25.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"
@class GangweiSetModel ;
@interface GangweiSetShowViewController : BaseViewController
@property(nonatomic,strong)GangweiSetModel* model;

@end
