//
//  QudaoView.h
//  WiseAPP
//
//  Created by app on 16/10/24.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QudaoView : UIView
@property(nonatomic,strong)UITextField* FriendName;
@property(nonatomic,strong)UITextField* frientNum;
@property(nonatomic,strong)UIButton* cannelBtn;
@property(nonatomic,strong)UIButton* doneBtn;
@property(nonatomic,strong)UILabel* titleLabel;
@end
