//
//  TimeTableViewCell.h
//  WiseAPP
//
//  Created by app on 16/11/30.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimeTableViewCell : UITableViewCell
@property(nonatomic,strong)UIImageView* timeBgImage;
@property(nonatomic,strong)UILabel* timeLa;
@property(nonatomic,strong)UILabel* timeweekLa;
@end
