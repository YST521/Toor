//
//  ImageViewController.h
//  app 引导页面
//
//  Created by lanou3g on 16/3/3.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController

@property(nonatomic,strong)UIScrollView*scroll;
@property(nonatomic,strong)UIPageControl*page;

@end
