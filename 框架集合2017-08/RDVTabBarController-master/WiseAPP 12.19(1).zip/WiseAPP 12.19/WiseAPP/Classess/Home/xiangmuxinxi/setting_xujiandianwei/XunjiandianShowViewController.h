//
//  XunjiandianShowViewController.h
//  WiseAPP
//
//  Created by yst911521 on 2016/11/23.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"
@class XunjiandanModel;
@interface XunjiandianShowViewController : BaseViewController
@property(nonatomic,strong)XunjiandanModel*model;
@end
