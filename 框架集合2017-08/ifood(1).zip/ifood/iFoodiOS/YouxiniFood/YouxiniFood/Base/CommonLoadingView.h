//
//  CommonLoadingView.h
//  ND591UP
//
//  Created by on 11-10-17.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
/*
 通用加载视图，显示加载图标和加载提示
 */
@interface CommonLoadingView : UIView 
{
}

//初始化通用加载视图
-(id)initWithInfo:(CGRect)frame info:(NSString*)info;
-(id)initwithColor:(UIColor *)color frame:(CGRect)frame info:(NSString *)info;

@end
