//
//  LinbaoAddView.h
//  WiseAPP
//
//  Created by app on 16/11/3.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LinbaoAddView : UIView
@property(nonatomic,strong)UITextField * activeNameFi;
@property(nonatomic,strong)UITextField * peopleFi;
@property(nonatomic,strong)UITextField* starTimFi;
@property(nonatomic,strong)UITextField* endTimFi;
@property(nonatomic,strong)UITextView*  describeFv;
@property(nonatomic,strong)UITextField* placeFi;
@property(nonatomic,strong)UITextField* phoneFi;
@property(nonatomic,strong)UITextField* numberFi;
@end
