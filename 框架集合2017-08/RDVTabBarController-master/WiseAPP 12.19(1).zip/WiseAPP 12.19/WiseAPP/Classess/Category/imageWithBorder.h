//
//  imageWithBorder.h
//  WiseAPP
//
//  Created by app on 16/10/28.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface imageWithBorder : UIImage
+ (UIImage *)imageWithBorderW:(CGFloat)borderW borderColor:(UIColor *)color image:(UIImage *)image;
@end
