//
//  JiaojiebanShowViewController.h
//  WiseAPP
//
//  Created by yst911521 on 2016/11/21.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"
@class JiaojiebanModel;
@interface JiaojiebanShowViewController : BaseViewController

@property(nonatomic,strong)JiaojiebanModel* model;
@end
