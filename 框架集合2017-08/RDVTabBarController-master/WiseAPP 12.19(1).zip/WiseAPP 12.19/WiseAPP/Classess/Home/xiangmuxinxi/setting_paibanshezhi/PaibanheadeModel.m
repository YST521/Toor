//
//  PaibanheadeModel.m
//  WiseAPP
//
//  Created by app on 16/12/14.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "PaibanheadeModel.h"

@implementation PaibanheadeModel

@end

@implementation  PaiBanCellModel


@end
