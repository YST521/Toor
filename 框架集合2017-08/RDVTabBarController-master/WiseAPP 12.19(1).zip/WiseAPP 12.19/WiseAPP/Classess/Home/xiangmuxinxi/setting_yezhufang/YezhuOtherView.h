//
//  YezhuOtherView.h
//  WiseAPP
//
//  Created by yst911521 on 2016/12/10.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YezhuOtherView : UIView
@property(nonatomic,strong)UILabel* popTitle;
@property(nonatomic,strong)UITextView* popTextFile;
@property(nonatomic,strong)UIButton* popDoneBtn;
@end
