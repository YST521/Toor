//
//  YezhuShowMessageViewController.h
//  WiseAPP
//
//  Created by app on 16/11/17.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"
@class YezhuModel;
@interface YezhuShowMessageViewController : BaseViewController
@property(nonatomic,strong)YezhuModel*model;
@end
