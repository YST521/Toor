//
//  DateChooseView.h
//  SoHeroAttendance
//
//  Created by 冯佳玉 on 16/9/27.
//  Copyright © 2016年 冯佳玉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DateChooseView : UIView
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (weak, nonatomic) IBOutlet UIButton *sureButton;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;

@end
