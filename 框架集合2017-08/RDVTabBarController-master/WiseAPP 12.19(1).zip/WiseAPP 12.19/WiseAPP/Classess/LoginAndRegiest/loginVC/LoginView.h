//
//  LoginView.h
//  WiseAPP
//
//  Created by app on 16/10/16.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginView : UIView
@property(nonatomic,strong)UITextField*loginPhNumber;
@property(nonatomic,strong)UITextField*loginPassword;
@property(nonatomic,strong)UIButton*loginBtn;
@property(nonatomic,strong)UITextField*phoneNum;
@property(nonatomic,strong)UITextField*password;
@property(nonatomic,strong)UIButton*eyeBtn;
@property(nonatomic,strong)UIButton*menmoryBtn;
@property(nonatomic,strong)UIButton*remberBtn;
@property(nonatomic,strong)UIButton*regestBtn;
@end
