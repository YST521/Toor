//
//  AffMenger.m
//  WiseAPP
//
//  Created by app on 16/10/24.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "AffMenger.h"
#import "AFNetworking.h"

@implementation AffMenger

//+(void)AFNetworkPOSTurl:(NSString *)urlString paraments:(NSDictionary *)dic complete:(complete)complete{
//    AFHTTPRequestOperationManager * manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:MainURL_string]];
//    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/html",@"text/json", nil];
//    
//    [manager POST:urlString parameters:dic success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        if (complete) {
//            complete(responseObject, nil);
//        }
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        //            请求失败。
//        if (complete) {
//            complete(nil, error);
//        }
//    }];
//    
//}
@end
