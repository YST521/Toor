//
//  PeopleBanciAddCell.h
//  WiseAPP
//
//  Created by app on 16/11/29.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PeopleBanciAddCell : UITableViewCell
@property(nonatomic,strong)UILabel* quebianLeftLa;
@property(nonatomic,strong)UIButton* quebianleftBtn;
@property(nonatomic,strong)UILabel * quebianLa;
@property(nonatomic,strong)UIButton* quebianRightBtn;
//@property(nonatomic,strong)UILabel* quebianrightLa;

@end
