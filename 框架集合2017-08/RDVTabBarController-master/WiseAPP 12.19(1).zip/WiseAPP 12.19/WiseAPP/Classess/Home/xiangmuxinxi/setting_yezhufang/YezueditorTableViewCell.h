//
//  YezueditorTableViewCell.h
//  WiseAPP
//
//  Created by yst911521 on 2016/12/12.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YezueditorTableViewCell : UITableViewCell
@property(nonatomic,strong)UILabel* leftLa;
@property(nonatomic,strong)UILabel* rightLa;
@property(nonatomic,strong)UIButton* rightImage;
@end
