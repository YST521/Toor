//
//  SectionModel.m
//  CollectionView-nib
//
//  Created by chenyufeng on 15/11/30.
//  Copyright © 2015年 chenyufengweb. All rights reserved.
//

#import "SectionModel.h"

@implementation SectionModel

@end
