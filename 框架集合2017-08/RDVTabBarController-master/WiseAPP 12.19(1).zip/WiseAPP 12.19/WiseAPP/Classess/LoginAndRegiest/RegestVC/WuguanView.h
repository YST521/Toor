//
//  WuguanView.h
//  WiseAPP
//
//  Created by app on 16/10/16.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WuguanView : UIView

@property(nonatomic,strong)UITextField* wuguanPhNum;
@property(nonatomic,strong)UITextField* wuguanCompany;
@property(nonatomic,strong)UITextField* wuguanPosition;
@property(nonatomic,strong)UITextField* wuguanEmail;
@property(nonatomic,strong)UIButton* commitBtn;

@end
