//
//  RequestGongshiTableViewCell.h
//  WiseAPP
//
//  Created by app on 16/11/29.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RequestGongshiTableViewCell : UITableViewCell
@property(nonatomic,strong)UILabel* leftNameLa;
@property(nonatomic,strong)UILabel* leftBanciLa;
@property(nonatomic,strong)UILabel* leftDaysLa;
@property(nonatomic,strong)UILabel* rightAuditLa;
@end
