//
//  GongshiDataModel.m
//  WiseAPP
//
//  Created by app on 16/12/8.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "GongshiDataModel.h"

@implementation GongshiDataModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{


}
@end
