//
//  YingpingQudaoViewController.m
//  WiseAPP
//
//  Created by app on 16/11/9.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "YingpingQudaoViewController.h"

@implementation YingpingQudaoViewController

@end
