//
//  RegestView.h
//  WiseAPP
//
//  Created by app on 16/10/16.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegestView : UIView
@property(nonatomic,strong)UIButton*backBtn;
@property(nonatomic,strong)UIButton*typeBtn;
@property(nonatomic,strong)UIButton* viditionBtn;
@property(nonatomic,strong)UIButton* nextBtn;
@property(nonatomic,strong)UIButton* firstEyeBtn;
@property(nonatomic,strong)UIButton* secendEyeBtn;
@property(nonatomic,strong)UIButton*  agreeBtn;
@property(nonatomic,strong)UIButton* agreeContentBtn;

@property(nonatomic,strong)UITextField* userPhoneNum;
@property(nonatomic,strong)UITextField* userCode;
@property(nonatomic,strong)UITextField* userPassword;
@property(nonatomic,strong)UITextField* userPsAgain;



@end
