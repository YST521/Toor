//
//  JIaojiebanView.h
//  WiseAPP
//
//  Created by yst911521 on 2016/10/30.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JIaojiebanView : UIView
@property(nonatomic,strong)UITextField* produceFile;
@property(nonatomic,strong)UITextView * contentFile;
//@property(nonatomic,strong)UIButton* addImageBtn;
//@property(nonatomic,strong)UIView* addImageView;
@property(nonatomic,strong)UIView* photoView;

@end
