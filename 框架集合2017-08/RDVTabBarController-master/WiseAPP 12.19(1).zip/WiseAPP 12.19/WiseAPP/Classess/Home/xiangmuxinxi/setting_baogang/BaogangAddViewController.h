//
//  BaogangAddViewController.h
//  WiseAPP
//
//  Created by app on 16/11/3.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@class BangangModel;
@interface BaogangAddViewController : BaseViewController
@property(nonatomic,strong)BangangModel*model;
@property(nonatomic,assign)NSInteger upPageType;

@end
