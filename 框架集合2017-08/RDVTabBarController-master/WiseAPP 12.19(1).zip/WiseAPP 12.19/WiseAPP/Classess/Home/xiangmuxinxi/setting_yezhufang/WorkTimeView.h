//
//  WorkTimeView.h
//  WiseAPP
//
//  Created by app on 16/12/1.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WorkTimeView : UIView
@property(nonatomic,strong)UILabel* popTitle;
@property(nonatomic,strong)UITextField* starTimeFile;
@property(nonatomic,strong)UIButton* popDoneBtn;
@property(nonatomic,strong)UITextField* endTimeFile;

@end
