//
//  SuccViewController.h
//  DKNightVersion
//
//  Created by Draveness on 4/28/15.
//  Copyright (c) 2015 Draveness. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuccViewController : UIViewController

@end
