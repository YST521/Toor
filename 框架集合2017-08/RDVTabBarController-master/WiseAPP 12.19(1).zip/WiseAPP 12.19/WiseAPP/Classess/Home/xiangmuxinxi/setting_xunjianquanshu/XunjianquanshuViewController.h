//
//  XunjianquanshuViewController.h
//  WiseAPP
//
//  Created by app on 16/10/13.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@interface XunjianquanshuViewController : BaseViewController

@end
