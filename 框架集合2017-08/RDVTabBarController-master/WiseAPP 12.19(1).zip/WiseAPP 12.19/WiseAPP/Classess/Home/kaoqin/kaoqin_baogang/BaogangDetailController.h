//
//  BaogangDetailController.h
//  WiseAPP
//
//  Created by app on 16/12/6.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@interface BaogangDetailController : BaseViewController
@property(nonatomic,strong)UIImage*image;
@end
