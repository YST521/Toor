//
//  RegestViewController.h
//  WiseAPP
//
//  Created by app on 16/10/16.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@interface RegestViewController : BaseViewController

@end
