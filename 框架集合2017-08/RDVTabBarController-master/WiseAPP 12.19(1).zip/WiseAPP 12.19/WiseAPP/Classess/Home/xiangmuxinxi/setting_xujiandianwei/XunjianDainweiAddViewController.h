//
//  XunjianDainweiAddViewController.h
//  WiseAPP
//
//  Created by app on 16/11/4.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"
@class XunjiandanModel;
@interface XunjianDainweiAddViewController : BaseViewController
@property(nonatomic,strong)XunjiandanModel* model;
@property(nonatomic,assign)NSInteger upPageType;
@end
