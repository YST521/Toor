//
//  LoginrequestModel.m
//  WiseAPP
//
//  Created by yst911521 on 2016/11/10.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "LoginrequestModel.h"

@implementation LoginrequestModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{



}
@end
