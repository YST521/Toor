//
//  RegestModel.h
//  WiseAPP
//
//  Created by yst911521 on 2016/11/10.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RegestModel : NSObject
@property(nonatomic,assign)int resultCode;
@property(nonatomic,strong)NSString *resultMessage;
@end
