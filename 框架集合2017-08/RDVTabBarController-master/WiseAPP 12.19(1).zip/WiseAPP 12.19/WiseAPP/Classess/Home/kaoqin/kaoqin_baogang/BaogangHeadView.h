//
//  BaogangHeadView.h
//  WiseAPP
//
//  Created by app on 16/12/5.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaogangHeadView : UIView
@property(nonatomic,strong)UIImageView* roundView;
@property(nonatomic,strong)UILabel* timeLa;
@property(nonatomic,strong)UILabel* cuttreeTimeLa;
@property(nonatomic,strong)UIView* bgview;
@property(nonatomic,strong)UILabel* banciLa;
@property(nonatomic,strong)UILabel*  shijibaogangLa;
@property(nonatomic,strong)UILabel* yingbaogangLa;
@property(nonatomic,strong)UILabel* weibaogangLa;
@property(nonatomic,strong)UILabel* leftTitleLa;
@property(nonatomic,strong)UILabel* rightTitleLa;

@end
