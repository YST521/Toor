//
//  KaoqinHomeController.h
//  WiseAPP
//
//  Created by yst911521 on 2016/11/29.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@interface KaoqinHomeController : BaseViewController

@end
