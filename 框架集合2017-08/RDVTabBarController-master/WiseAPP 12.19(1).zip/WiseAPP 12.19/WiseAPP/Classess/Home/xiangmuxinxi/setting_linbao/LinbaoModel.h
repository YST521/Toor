//
//  LinbaoModel.h
//  WiseAPP
//
//  Created by app on 16/11/21.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LinbaoModel : NSObject

@property(nonatomic,copy)NSString*endtime;
@property(nonatomic,copy)NSString*projectleader;
@property(nonatomic,copy)NSString*projectname;
@property(nonatomic,copy)NSString*startingtime;
@property(nonatomic,copy)NSString*address;
@property(nonatomic,copy)NSString*phone;
@property(nonatomic,copy)NSString*des;
@property(nonatomic,copy)NSString*number;



@property(nonatomic,assign)int id;

@end
