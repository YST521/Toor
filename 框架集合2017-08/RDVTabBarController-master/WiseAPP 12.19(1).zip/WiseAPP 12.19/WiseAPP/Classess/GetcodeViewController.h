//
//  GetcodeViewController.h
//  WiseAPP
//
//  Created by yst911521 on 2016/11/13.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetcodeViewController : UIViewController
@property(nonatomic,strong)NSString* la;
@property(nonatomic,strong)NSString* lon;
@end
