//
//  JiaojiebanModel.h
//  WiseAPP
//
//  Created by yst911521 on 2016/11/21.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JiaojiebanModel : NSObject


@property(nonatomic,copy)NSString*matter;
@property(nonatomic,copy)NSString* mattername;
@property(nonatomic,assign)int jiaojiebanID;

@property(nonatomic,strong)NSArray*image;


@end
