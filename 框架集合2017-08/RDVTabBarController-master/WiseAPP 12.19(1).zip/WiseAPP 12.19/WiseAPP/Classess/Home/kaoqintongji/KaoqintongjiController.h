//
//  KaoqintongjiController.h
//  WiseAPP
//
//  Created by app on 16/12/5.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@interface KaoqintongjiController : BaseViewController

@end
