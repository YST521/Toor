//
//  XunjianquanshuTableViewCell.h
//  WiseAPP
//
//  Created by app on 16/11/4.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XunjianquanshuTableViewCell : UITableViewCell
@property(nonatomic,strong) UIButton* leftBtn;
@property(nonatomic,strong)UILabel* leftNumLa;
@property(nonatomic,strong)UILabel* leftAdressLa;
@property(nonatomic,strong)UILabel* rightLa;
@end
