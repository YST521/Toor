//
//  CellShenGaoView.h
//  WiseAPP
//
//  Created by app on 16/10/17.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellShenGaoView : UIView
@property(nonatomic,strong)UILabel*titleLabel;
@property(nonatomic,strong)UITextField* heightFile;
@property(nonatomic,strong)UIButton*backBtn;
@property(nonatomic,strong)UIButton*doneBtn;

@end
