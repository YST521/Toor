//
//  CreateLable.h
//  DZPK_V
//
//  Created by mippo on 9/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@interface CreateLable : NSObject {

}

//创建默认lable
+ (UILabel*)defaultLable:(CGRect)rect 
			   textColor:(UIColor*)col 
				textSize:(int)size 
					text:(NSString*)text
				  isBold:(BOOL)isBold
		   testAlignment:(NSTextAlignment)alignment;

@end
