//
//  SingleXiangmuxnxi.h
//  WiseAPP
//
//  Created by app on 16/11/7.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SingleXiangmuxnxi : NSObject
+(SingleXiangmuxnxi*)SingleXiangmuxinxiManger;
//数据读取

@property(nonatomic,strong)NSMutableArray* YezhumessageArray;
@property(nonatomic,strong)NSMutableDictionary* xiangmuprojectIdDic;
@end
