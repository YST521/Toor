//
//  MyCollectionViewCell.h
//  SoHeroAttendanceAPP
//
//  Created by 冯佳玉 on 16/9/26.
//  Copyright © 2016年 冯佳玉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UILabel *lunarLabel;
@property (weak, nonatomic) IBOutlet UILabel *workRestLabel;

@end
