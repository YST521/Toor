//
//  YezhuMainTableViewCell.h
//  WiseAPP
//
//  Created by app on 16/10/27.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YezhuMainTableViewCell : UITableViewCell

@property(nonatomic,strong)UILabel* leftLab;
@property(nonatomic,strong)UIImageView* rightImage;
@property(nonatomic,strong)UIImageView* nextImage;
@property(nonatomic,strong)UIImageView*bgImag;
@end
