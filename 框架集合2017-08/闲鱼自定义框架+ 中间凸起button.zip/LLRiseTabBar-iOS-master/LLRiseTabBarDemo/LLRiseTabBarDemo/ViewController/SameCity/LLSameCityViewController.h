//
//  LLSameCityViewController.h
//  LLRiseTabBarDemo
//
//  Created by Meilbn on 10/18/15.
//  Copyright © 2015 meilbn. All rights reserved.
//

#import "LLBaseViewController.h"

@interface LLSameCityViewController : LLBaseViewController

@end
