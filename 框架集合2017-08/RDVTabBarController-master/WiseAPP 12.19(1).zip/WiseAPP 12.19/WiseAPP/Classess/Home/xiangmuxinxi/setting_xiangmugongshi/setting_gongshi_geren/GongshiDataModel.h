//
//  GongshiDataModel.h
//  WiseAPP
//
//  Created by app on 16/12/8.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GongshiDataModel : NSObject
@property(nonatomic,assign)int actual;
@property(nonatomic,assign)int approved;
@property(nonatomic,assign)int attendance;
@property(nonatomic,assign)int remaininghours;
@property(nonatomic,assign)int workinghours;
@end
