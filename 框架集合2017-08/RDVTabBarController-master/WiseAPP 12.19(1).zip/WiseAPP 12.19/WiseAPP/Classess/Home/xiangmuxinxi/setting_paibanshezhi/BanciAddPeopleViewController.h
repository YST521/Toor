//
//  BanciAddPeopleViewController.h
//  WiseAPP
//
//  Created by app on 16/11/2.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@interface BanciAddPeopleViewController : BaseViewController
@property(nonatomic,assign)NSInteger addId;
@end
