//
//  SettingTableViewCell.h
//  WiseAPP
//
//  Created by app on 16/10/10.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingTableViewCell : UITableViewCell
@property(nonatomic,strong)UILabel*titleLabel;
@property(nonatomic,strong)UILabel* rightLa;
@property(nonatomic,strong)UIImageView*rightImage;
@end
