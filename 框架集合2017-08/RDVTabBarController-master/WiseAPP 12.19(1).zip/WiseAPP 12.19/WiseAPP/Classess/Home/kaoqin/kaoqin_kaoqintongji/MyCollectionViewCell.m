//
//  MyCollectionViewCell.m
//  SoHeroAttendanceAPP
//
//  Created by 冯佳玉 on 16/9/26.
//  Copyright © 2016年 冯佳玉. All rights reserved.
//

#import "MyCollectionViewCell.h"

@implementation MyCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
