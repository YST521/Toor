//
//  YezhuGenderView.h
//  WiseAPP
//
//  Created by yst911521 on 2016/12/10.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YezhuGenderView : UIView
@property(nonatomic,strong)UILabel* selectTitle;
//@property(nonatomic,strong)UIView* photoview;
//@property(nonatomic,strong)UIImageView* photoImage;
//@property(nonatomic,strong)UILabel* photoLabel;
//
//@property(nonatomic,strong)UIView* cameraView;
//@property(nonatomic,strong)UIImageView* cameraImage;
//@property(nonatomic,strong)UILabel* cameraLab;
@property(nonatomic,strong)UIButton* manBtn;
@property(nonatomic,strong)UIButton* womenBtn;

@end
