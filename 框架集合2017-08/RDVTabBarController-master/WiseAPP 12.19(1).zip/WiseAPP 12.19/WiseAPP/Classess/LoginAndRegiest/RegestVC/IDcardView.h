//
//  IDcardView.h
//  WiseAPP
//
//  Created by app on 16/10/17.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IDcardView : UIView
@property(nonatomic,strong)UIImageView*idCardA;
@property(nonatomic,strong)UIImageView*idCardB;
@property(nonatomic,strong)UIButton*playABtn;
@property(nonatomic,strong)UIButton*playBBtn;
@property(nonatomic,strong)UIButton*commitBtn;

@end
