//
//  AppDelegate.h
//  YTThemeDemo
//
//  Created by yitudev on 16/12/23.
//  Copyright © 2016年 xx公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

