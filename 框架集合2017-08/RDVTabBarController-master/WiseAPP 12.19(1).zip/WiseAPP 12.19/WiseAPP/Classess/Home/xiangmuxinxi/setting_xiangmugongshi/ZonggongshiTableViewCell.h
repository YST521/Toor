//
//  ZonggongshiTableViewCell.h
//  WiseAPP
//
//  Created by yst911521 on 2016/11/14.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZonggongshiTableViewCell : UITableViewCell
@property(nonatomic,strong)UIButton* leftselectbtn;
@property(nonatomic,strong)UILabel* leftla;
@property(nonatomic,strong)UILabel* rightla;
@property(nonatomic,strong)UITextField* rightFi;

@end
