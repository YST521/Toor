//
//  BaogangAddTimeCell.h
//  WiseAPP
//
//  Created by app on 16/12/8.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaogangAddTimeCell : UITableViewCell
@property(nonatomic,strong)UILabel* leftLa;
@property(nonatomic,strong)UIButton* rightBtn;
@end
