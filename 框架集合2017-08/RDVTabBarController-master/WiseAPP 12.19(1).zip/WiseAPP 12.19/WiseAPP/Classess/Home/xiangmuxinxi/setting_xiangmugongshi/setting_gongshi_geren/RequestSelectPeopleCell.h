//
//  RequestSelectPeopleCell.h
//  WiseAPP
//
//  Created by app on 16/12/15.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RequestSelectPeopleCell : UITableViewCell
@property(nonatomic,strong) UIButton* leftBtn;
@property(nonatomic,strong)UILabel* peopleNameLa;
@end
