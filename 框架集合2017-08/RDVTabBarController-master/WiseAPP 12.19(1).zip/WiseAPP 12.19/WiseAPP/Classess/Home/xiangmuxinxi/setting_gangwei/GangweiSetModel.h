//
//  GangweiSetModel.h
//  WiseAPP
//
//  Created by app on 16/11/25.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseModel.h"

@interface GangweiSetModel : BaseModel
@property(nonatomic,assign)int gangweiID;
@property(nonatomic,copy)NSString*jobassignment;
@property(nonatomic,copy)NSString* post;
@end
