//
//  WuGuanRegestViewController.h
//  WiseAPP
//
//  Created by app on 16/10/16.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"

@interface WuGuanRegestViewController : BaseViewController

@property(nonatomic,strong)NSString*wgPhoneNum;
//@property(nonatomic,strong)NSString* wgGetcode;
@property(nonatomic,strong)NSString *wgPassword;
//@property(nonatomic,strong)NSString* wgPasswordAgin;

@end
