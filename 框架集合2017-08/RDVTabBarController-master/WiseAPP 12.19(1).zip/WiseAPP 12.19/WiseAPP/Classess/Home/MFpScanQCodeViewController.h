//
//  MFpScanQCodeViewController.h
//  MfpQRCode
//
//  Created by 浙江梦之想 on 16/3/30.
//  Copyright © 2016年 浙江梦之想. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MFpScanQCodeViewController : UIViewController

@end
