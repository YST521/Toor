//
//  FindCompanyCell.h
//  WiseAPP
//
//  Created by app on 16/10/21.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FindCompanyCell : UICollectionViewCell
@property(nonatomic,strong)UIImageView*bgimageView;
@property(nonatomic,strong)UIImageView*iconImageView;
@property(nonatomic,strong)UILabel* titleLabel;
@property(nonatomic,strong)UIView*upView;
@end
