//
//  CellJinjiLianxirenView.h
//  WiseAPP
//
//  Created by app on 16/10/18.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellJinjiLianxirenView : UIView
@property(nonatomic,strong)UITextField*contanctName;
@property(nonatomic,strong)NSString*contentBetween;
@property(nonatomic,strong)UITextField* contentPhone;

@property(nonatomic,strong)UIButton* motherBtn;
@property(nonatomic,strong)UIButton* fatherBtn;
@property(nonatomic,strong)UIButton* sisterBtn;
@property(nonatomic,strong)UIButton* brotherBtn;

@property(nonatomic,strong)UIButton* saveBtn;
@end
