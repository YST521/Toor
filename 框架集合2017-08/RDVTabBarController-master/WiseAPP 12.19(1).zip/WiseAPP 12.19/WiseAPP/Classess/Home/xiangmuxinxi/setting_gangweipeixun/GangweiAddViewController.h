//
//  GangweiAddViewController.h
//  WiseAPP
//
//  Created by app on 16/11/1.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"
@class GangweiModel;
@interface GangweiAddViewController : BaseViewController
@property(nonatomic,strong)GangweiModel*model;
@property(nonatomic,assign)NSInteger gangweiUppgType ;

@end
