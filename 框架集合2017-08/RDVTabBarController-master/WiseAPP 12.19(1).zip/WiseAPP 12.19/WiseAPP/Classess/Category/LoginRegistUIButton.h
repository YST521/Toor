//
//  LoginRegistUIButton.h
//  百思不得其姐
//
//  Created by lanou3g on 16/5/27.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginRegistUIButton : UIButton

@end
