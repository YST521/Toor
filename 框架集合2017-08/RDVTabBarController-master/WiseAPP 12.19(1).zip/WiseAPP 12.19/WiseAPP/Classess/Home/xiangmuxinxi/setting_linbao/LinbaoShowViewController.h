//
//  LinbaoShowViewController.h
//  WiseAPP
//
//  Created by app on 16/11/21.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"
@class LinbaoModel;
@interface LinbaoShowViewController : BaseViewController
@property(nonatomic,strong)LinbaoModel* linbaoModel;
@end
