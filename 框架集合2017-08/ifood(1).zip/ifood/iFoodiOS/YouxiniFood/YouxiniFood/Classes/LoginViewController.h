//
//  LoginViewController.h
//  YouxiniFood
//
//  Created by yst911521 on 2017/7/26.
//  Copyright © 2017年 YST. All rights reserved.
//

#import "BaseViewController.h"

@interface LoginViewController : BaseViewController

@end
