//
//  WoryTypeMessageCell.h
//  WiseAPP
//
//  Created by app on 16/10/17.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WoryTypeMessageCell : UITableViewCell

@property(nonatomic,strong)UIImageView *leftIcon;
@property(nonatomic,strong)UILabel*leftLabel;
@property(nonatomic,strong)UILabel*rightLabel;
@property(nonatomic,strong)UIImageView*rightImage;


@end
