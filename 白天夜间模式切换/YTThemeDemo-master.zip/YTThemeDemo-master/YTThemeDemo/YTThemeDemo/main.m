//
//  main.m
//  YTThemeDemo
//
//  Created by yitudev on 16/12/23.
//  Copyright © 2016年 xx公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
