//
//  KaoqinDetaileView.h
//  WiseAPP
//
//  Created by app on 16/12/5.
//  Copyright © 2016年 YST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KaoqinDetaileView : UIView
@property(nonatomic,strong)UIImageView* bgImageV;
@property(nonatomic,strong)UILabel* titleLa;
@property(nonatomic,strong)UILabel* starTime;
@property(nonatomic,strong)UILabel* endTime;
@property(nonatomic,strong)UILabel* starkaoqinLa;
@property(nonatomic,strong)UILabel* endKoaqinLa;
@property(nonatomic,strong)UILabel* starAdressLa;
@property(nonatomic,strong)UILabel* endStrAdressLa;


@end
