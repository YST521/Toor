//
//  XunjianquanshuAddViewController.h
//  WiseAPP
//
//  Created by app on 16/11/4.
//  Copyright © 2016年 YST. All rights reserved.
//

#import "BaseViewController.h"
@class XunjianQuanshuModel;
@interface XunjianquanshuAddViewController : BaseViewController
@property(nonatomic,strong)XunjianQuanshuModel*model;
@property(nonatomic,assign)NSInteger uppageType;

@end
